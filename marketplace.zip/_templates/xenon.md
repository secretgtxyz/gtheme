---
layout:       template
name:         Xenon
title:        Xenon - News & Magazine Clean Ghost Theme
date:         2017-12-24
thumbnail:    /assets/image/template2.jpg
price:        39
categories:   templates
type:         Ghost
body-class:   is-theme
demo_link:    http://xenon.themeix.com/
docs:          /docs/xenon-ghost
purchase_link: http://themeforest.net/item/
description:  Xenon Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus mollitia doloribus porro quisquam nihil praesentium quas, quod maiores excepturi voluptas, tenetur beatae maxime, aliquid est nisi architecto quam velit inventore!
features:
  - Clean Design
  - Responsive Layout
  - Subscription Form
  - Instant Search
  - Related Posts
  - Disqus Comments
  - Twitter Feed Widget
  - Instagram Feed Widget
  - Recent Posts Widget
  - Advertisement Widget
  - Post Sharing
  - HTML5 Markup
  - Custom Logo
  - Author & Tag Pages
  - SEO Optimized
  - Developer Friendly
  - Sass & Gulp Automation
  - Free Customer Support
---

Aspire is created for those who want to create a beautiful online magazine or news website.

Aspire it is 100% responsive, that means it fits with all different kind of devices in different sizes.

![aspire-ghost-full-preview](/images/themes/ghost/aspire/full-preview.png)