---
layout:       template
name:         Cleanhost
title:        Appix - News & Magazine Clean Ghost Theme
date:         2017-12-24
thumbnail:    /assets/image/template.jpg
price:        39
categories:   templates
type:         Ghost
body-class:   is-theme
demo_link:    http://appix.themeix.com/
docs:          /docs/xenon-ghost
purchase_link: http://themeforest.net/item/
description:  Cleanhost is a modern web hosting HTML5 Template for all kinds of hosting company. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam maxime voluptatibus eum libero. Deserunt repudiandae doloremque illum, earum quos odio obcaecati ex iure debitis consectetur repellat eos esse provident at.
features:
  - Clean Design
  - Responsive Layout
  - Subscription Form
  - Instant Search
  - Related Posts
  - Disqus Comments
  - Twitter Feed Widget
  - Instagram Feed Widget
  - Recent Posts Widget
  - Advertisement Widget
  - Post Sharing
  - HTML5 Markup
  - Custom Logo
  - Author & Tag Pages
  - SEO Optimized
  - Developer Friendly
  - Sass & Gulp Automation
  - Free Customer Support
---

Aspire is created for those who want to create a beautiful online magazine or news website.

Aspire it is 100% responsive, that means it fits with all different kind of devices in different sizes.

![aspire-ghost-full-preview](/images/themes/ghost/aspire/full-preview.png)